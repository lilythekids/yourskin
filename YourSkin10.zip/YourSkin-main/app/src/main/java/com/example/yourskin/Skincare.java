package com.example.yourskin;

public abstract class Skincare{
    public abstract int getID();
    public abstract String getNameSkin();
    public abstract String getIngredient();
    public abstract String getImage();
    public abstract String getNameCategory();
}
